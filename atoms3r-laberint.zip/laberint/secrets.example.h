#pragma once
const char* WIFI_SSID = "EL_TEU_WIFI";
const char* WIFI_PASS = "LA_TEVA_CONTRASENYA";
const char* FIREBASE_URL = "https://EL-TEU-PROJECTE-default-rtdb.europe-west1.firebasedatabase.app";
